package GSI_Java_OOPS_Assignment;

class Calculator
{

int add(int a, int b)
{  
	return a+b;
}

double add(double a, double b){
	return a+b;
	
}
}

public class Question4 {
	public static void main(String[] args) {
		Calculator c = new Calculator();
		System.out.println(c.add(20, 30));
		System.out.println(c.add(50.25, 30.23));
		
		
	}

}
