package GSI_Java_OOPS_Assignment;

class Device{
	void start() {		
	System.out.println("Welcome to Nokia");}
}

class Mobile extends Device
{
	void calling()
	{System.out.println("Tring Tring");
	}
}

class SmartPhone extends Mobile{
	void internet()
	{
		System.out.println("5G Network");
	}
}

public class Question13 {
	public static void main(String[] args) {
		SmartPhone s = new SmartPhone();
		s.start();
		s.calling();
		s.internet();

	}

}
