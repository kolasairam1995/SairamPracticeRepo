package GSI_Java_OOPS_Assignment;

interface Payment
{
	void makePayment();
}

class UPI implements Payment
{
	public void makePayment()
	{
	 System.out.println("UPI transaction successful");	
	}
}

class CreditCard implements Payment
{
	public void makePayment()
	{
	 System.out.println("Credit card transaction successful");	
	}
}

public class Question6 {
	public static void main(String[] args) {
	Payment p = new UPI();
	p.makePayment();
	
	Payment p1 = new CreditCard();
	p1.makePayment();
		
	}

}
