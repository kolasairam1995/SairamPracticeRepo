package GSI_Java_OOPS_Assignment;

class Student10{
	static String collegeName="BVRIT";
	String name;
	int rollno;	
	Student10(String name, int rollno)
	{
		this.name=name;
		this.rollno=rollno;	}	
	void print()
	{
		System.out.println(collegeName+" "+name+" "+rollno);			
	}}
public class Question10 {
	public static void main(String[] args) {
    Student10 s = new Student10("Sai", 391);
    s.print();
    Student10 s1 = new Student10("Ram", 393);
    s1.print();
	}

}
