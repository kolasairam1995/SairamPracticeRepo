package GSI_Java_OOPS_Assignment;

abstract class Employee17 {
	abstract void calculateSalary();
	void employeeDetails()
	{
		System.out.println("Employee name");
	}
}

class FullTimeEmployee extends Employee17{
	void calculateSalary()
	{ int n=30, hrs=8;
	  int salary=30*4*500;
		System.out.println("salary for full time employee::"+" "+salary);
	}
}


class PartTimeEmployee extends Employee17 {
	void calculateSalary()
	{ int n=15, hrs=4;
	  int salary=15*4*400;
		System.out.println("salary for part time employee::"+" "+salary);
	}
}

public class Question17 {
	public static void main(String[] args) {
	Employee17 e = new FullTimeEmployee();
	e.calculateSalary();	
	Employee17 e1 = new PartTimeEmployee();
	e1.calculateSalary();
		
	}
}
