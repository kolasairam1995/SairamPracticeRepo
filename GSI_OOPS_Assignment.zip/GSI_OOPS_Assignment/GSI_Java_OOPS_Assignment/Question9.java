package GSI_Java_OOPS_Assignment;

class Bank{
	final String IFSC = "SBIN0011664";	
	final void showIFSC() {
		System.out.println(IFSC);
	}	
}

class HDFCBank extends Bank{
	void showIFSC()   // ---->   compile time error
	{
		System.out.println("Subclass IFSC");
	}	
}

public class Question9 {
	public static void main(String[] args) {
		HDFCBank h = new HDFCBank();
		h.showIFSC();
	}
}
