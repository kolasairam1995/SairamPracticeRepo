package GSI_Loops_Assignment;

import java.util.Scanner;

public class Question19 {
	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    int option;  
    System.out.println("Menu options available from 1 to 4");
	System.out.println("1 - Add,"+" "+"2 - Sub,"+" "+"3 - Mult,"+" "+"4 - Exit");
	System.out.println();
    do
    {
    	System.out.println("Please enter option");  	
    	option=sc.nextInt();  	
    	if(option>=1 && option<=3)
    	{	System.out.println("Enter first number");
    		int num1 = sc.nextInt();
    		System.out.println("Enter second number");
    		int num2= sc.nextInt();   		
   	
    	switch (option)
    	{
    	case 1:  System.out.println("Add:"+" "+(num1+num2));
    	break;
    	case 2:  System.out.println("subract:"+" "+(num1-num2));
    	break;
    	case 3:  System.out.println("Multiply:"+" "+(num1*num2));
    	break;    	
    	}
    	}   	
    	else if (option==4)
    	{  System.out.println("Exit");
    		break; 
    	}
    	System.out.println();
    }
    
    while(option>0);
    {
    	
    }
    
    
  sc.close();  
	}
}
