package GSI_Loops_Assignment;

public class Question18 {

	public static void main(String[] args) {
    int i=1;
    do
    {
    	System.out.println( "Loop Executed");
    	i++;
    }    
    while(i>10);
	}
}
