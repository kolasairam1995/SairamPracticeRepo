package GSI_Java_OOPS_Assignment;

class Library{
	String libraryName="Explore";  
   
	Library(){
	System.out.println("Welcome to the Library!");
	}

   void showLocation()
   {
	   System.out.println("This library is located in Mumbai");
   }
}

public class Question11 {
	public static void main(String[] args) {
		Library l = new Library();
		l.showLocation();		
	}

}
