package GSI_Loops_Assignment;
import java.util.Scanner;

public class Question16 {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int num, count=0;
	
	do {		
		System.out.println("Enter the number");
	    num = sc.nextInt();	    
	    if(num<0)
	    {
	    	break;
	    }		
	    if(num%2==0)
	    {
	    	count=count+num;
	    }	    
	}				
	while(num>0);
	{
		
	}
System.out.println("sum of even numbers entered" +" "+count);	
sc.close();

	}
}
