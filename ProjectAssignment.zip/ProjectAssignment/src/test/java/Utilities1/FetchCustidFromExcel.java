package Utilities1;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Constants_Datas.ConstantData1;

public class FetchCustidFromExcel {

    public static String getCustomerID(int x, int y) throws IOException {

        FileInputStream f = new FileInputStream(ConstantData1.EXCEL_PROP_PATH);

        XSSFWorkbook wb = new XSSFWorkbook(f);
        XSSFSheet sheet = wb.getSheetAt(0);

        int lastRow = sheet.getLastRowNum();

        XSSFRow row = sheet.getRow(lastRow);
        XSSFCell cell = row.getCell(0);

        String custid = cell.toString();

        wb.close();

        return custid;
    }
}