@sanity
Feature: Login functionality of demo guru 99

  Scenario Outline: Validate login
    Given user opens browser
    And user enters username as "<username>"
    And user enters password as "<password>"
    When user clicks Login button
    Then user navigates to homepage of the application
    And user closes the browser

    Examples: 
      | username  | password |
      | mngr26593 | 12!@     |
