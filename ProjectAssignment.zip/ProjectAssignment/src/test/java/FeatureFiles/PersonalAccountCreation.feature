@sanity
Feature: Creaton of New Account

  Scenario: Create new customer with all details
    Given user opens browser
    And user enters username as "mngr26593"
    And user enters password as "12!@"
    When user clicks Login button
    Then user navigates to homepage of the application
    And customer clicks on New account link
    And customer enters customerid
    And customer enters deposit as "5000"
    And user clicks on account submit button
    Then new account gets created
    And user captures account id
    And user closes the browser
