package GSI_Loops_Assignment;

public class Question13 {
	public static void main(String[] args) {

		int num = 2435789;
		int count = 0, rem;
		System.out.println("Given number is" +" "+num);
		
		while(num>0)
		{
			rem = num%10;
			{
				if(rem>1) 
			  {
				if (rem==2 || rem==3 || rem==5 || rem==7)
				{
					count++;
					System.out.println(rem+" "+"is Prime digit");
				}
			   }   
			}
		
			num=num/10;					
		}
		
		System.out.println("Count of prime digits in a number" +" "+count);
	}

}
