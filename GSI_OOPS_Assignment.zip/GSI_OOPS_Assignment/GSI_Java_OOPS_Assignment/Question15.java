package GSI_Java_OOPS_Assignment;

class LoanCalculator{
void calculateLoan(int amount)
{
	System.out.println("amount:" +amount);
}

void calculateLoan(int amount, double interestRate)
{
	System.out.println("amount:" +amount);
	System.out.println("interestRate:"+interestRate);
}
}

public class Question15 {
	public static void main(String[] args) {
	LoanCalculator l = new LoanCalculator();
	l.calculateLoan(800000);
	l.calculateLoan(500000, 8.5);
	}

}
