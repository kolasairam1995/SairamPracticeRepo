package PageRepository1;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NewCustomerPage1 {

	  WebDriver driver;
		
		public NewCustomerPage1(WebDriver driver)
		{
			this.driver=driver;
			PageFactory.initElements(driver, this);	
		}
		
		@FindBy (xpath="//*[text()='New Customer']")
		WebElement NewCustomerlink;
		
		@FindBy (xpath="//input[@name='name']")
		WebElement Cname;
		
		@FindBy (xpath="//input[@name='dob']")
		WebElement Dob;
		
		@FindBy (xpath="//textarea[@name='addr']")
		WebElement Add;
		
		@FindBy (xpath="//input[@name='city']")
		WebElement City;
		
		@FindBy (xpath="//input[@name='state']")
		WebElement State;
		
		@FindBy (xpath="//input[@name='pinno']")
		WebElement Pin;

		@FindBy (xpath="//input[@name='telephoneno']")
		WebElement Mobile;
		
		@FindBy (xpath="//input[@name='emailid']")
		WebElement Email;
		
		@FindBy (xpath="//input[@name='password']")
		WebElement Pwd;
		
		@FindBy (xpath="//input[@name='sub']")
		WebElement Submit;
		
		@FindBy (xpath="//*[text()='Customer ID']//following::td[1]")
		WebElement customerid;
		
		
		
		
		@FindBy (xpath="//*[text()='New Account']")
		WebElement NewAccount;
			
		@FindBy (xpath="//input[@name='cusid']")
		WebElement custid;
		
		@FindBy (xpath="//input[@name='inideposit']")
		WebElement deposit;
		
		@FindBy (xpath="//input[@name='button2']")
		WebElement sub1;
		
		@FindBy (xpath="//*[text()='Account ID']//following::td[1]")
		WebElement accountid;
		
		@FindBy (xpath="//*[text()='Log out']")
		WebElement logout;
		
		
		
		
		public void clickNewCustomerLink() {
			NewCustomerlink.click();
		}
		
		public void enterUsername(String cname)
		{
			Cname.sendKeys(cname);
		}
		
		
		public void enterDob(String DOB)
		{
			Dob.sendKeys(DOB);
		}
		
		public void enterAddr(String Addr)
		{
			Add.sendKeys(Addr);
		}
		
		public void enterCity(String city)
		{
			City.sendKeys(city);
		}
		
		public void enterState(String state)
		{
			State.sendKeys(state);
		}
		
		public void enterPincode(String pincode)
		{
			Pin.sendKeys(pincode);
		}
		
		public void enterMobile(String mobile)
		{
			Mobile.sendKeys(mobile);
		}
		
		public void enterEmail(String email)
		{
			Email.sendKeys(email);
		}
		
		public void enterPassword(String password)
		{
			Pwd.sendKeys(password);
		}
		
		public void clickSubmit()
		{
			Submit.click();
		}
		
		public String captureCustID()
		{
			String cid=customerid.getText();
			return cid;
		}

		
		
		
		
		
		
		public void clickNewAccount() {
			NewAccount.click();
		}
		
		public void enterCustid(String Custid)
		{
			custid.sendKeys(Custid);
		}
		
		
		public void enterDeposit(String dep)
		{
			deposit.sendKeys(dep);
		}
			
		
		public void clickSubmit1()
		{
			sub1.click();
		}
		
		
		public String captureAcctID()
		{
			String acctid=accountid.getText();
			return acctid;
		}
		
		
		public void clicklogout() throws InterruptedException
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
		    js.executeScript("arguments[0].click();", logout);
			Alert alert = driver.switchTo().alert();  
			alert.accept();
	    }
			
		
		
		
		
		
		
		
	
		
}
