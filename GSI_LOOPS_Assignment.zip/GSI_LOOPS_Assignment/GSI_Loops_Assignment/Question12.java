package GSI_Loops_Assignment;

public class Question12 {
	public static void main(String[] args) {
		
	int num = 120456;
	
	int rev=0, rem;
	
	while(num>0)
	{
		rem = num%10;
		if(rem==0)
		{
			break;
		}
		num=num/10;
		rev=rev*10+rem;		
	}
		System.out.println("reverse stopped & rev number till zero digit is" + " "+rev);
		
		
		
		
		
		

	}

}
