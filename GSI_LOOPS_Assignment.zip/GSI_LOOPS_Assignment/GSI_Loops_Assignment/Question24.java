package GSI_Loops_Assignment;

public class Question24 {

	public static void main(String[] args) {
		
     for(int i=5; i>=1; i--)
     {
    	 for(int j=i; j>=1; j--)
    	 {
    		 System.out.print(j+" ");
    	 }
		System.out.println();
		}	
	} 	
	
}
