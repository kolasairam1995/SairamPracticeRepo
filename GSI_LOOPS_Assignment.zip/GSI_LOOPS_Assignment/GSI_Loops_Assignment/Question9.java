package GSI_Loops_Assignment;

import java.util.Scanner;

public class Question9 {
	public static void main(String[] args) {
    
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the character");
		char ch=sc.next().charAt(0);
		
		if(ch>='A' && ch<='Z')
		{
			if(ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')
			{
				System.out.println("Uppercase vowel");
			}
			else
			{
				System.out.println("Uppercase consonant");
			}
		}
		
		else
			if(ch>='a' && ch<='z')
			{
				if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u')
				{
					System.out.println("Lowercase vowel");
				}
				else
				{
					System.out.println("Lowercase consonant");
				}
			}
		
		sc.close();
	}

}
