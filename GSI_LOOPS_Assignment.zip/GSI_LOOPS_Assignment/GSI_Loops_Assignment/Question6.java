package GSI_Loops_Assignment;

import java.util.Scanner;

public class Question6 {

	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter Math marks");
    int math= sc.nextInt();		
    System.out.println("Enter physics marks");
    int physics= sc.nextInt();	
    System.out.println("Enter chemistry marks");
    int chemistry= sc.nextInt();
    int total = math+physics+chemistry;
		
    if((math>=60 && physics>=50 && chemistry>=40) && (total>=180 || (math+physics) >=120) )
    		{
    	System.out.println("Total Marks are " +total+" "+"- Eligible");
    		}
    else
    {
    	System.out.println("Not Eligible");
	}
    sc.close();
	}
}
