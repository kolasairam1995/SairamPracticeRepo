package GSI_Loops_Assignment;

import java.util.Scanner;

public class Question10 {

	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number");
    int num = sc.nextInt();
    int sum=0, rem;
    
   if (num>99)
    {
    	while(num>0)
    	{
    		rem = num%10;
    		num=num/10;
    		sum=sum+rem;
    	}
     if(sum%2==0)
     {
    	 System.out.println("Sum of digits is even");
    	 System.out.println(sum);
     }
     else
     {
    	 System.out.println("sum of digits is odd");
    	 System.out.println(sum);
     }
    }
     
   else
   {
	   System.out.println("Not a 3 digit number");
   }
sc.close();   
	}

} 
