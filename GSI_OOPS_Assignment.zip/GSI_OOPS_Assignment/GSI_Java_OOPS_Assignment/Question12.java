package GSI_Java_OOPS_Assignment;

class Account {
private String accountHolderName;
private int balance;

public String getAccountHolderName() { 
	return accountHolderName;
}
public void setAccountHolderName(String accountHolderName) {
	this.accountHolderName = accountHolderName;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
	if(balance <0)
	{
		System.out.println("Negative Balance");
	}
}
}

public class Question12 {
	public static void main(String[] args) {
		Account a = new Account();
		a.setAccountHolderName("Sairam");
		a.setBalance(-5000);		
		System.out.println("HolderName:"+" "+a.getAccountHolderName());
		System.out.println("Balance:"+" "+a.getBalance());
	}
}
