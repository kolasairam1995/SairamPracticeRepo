@sanity
Feature: Creaton of New Customer

  Scenario: Create new customer with all details
    Given user opens browser
    And user enters username as "mngr26593"
    And user enters password as "12!@"
    When user clicks Login button
    Then user navigates to homepage of the application
    And user clicks on new customer link
    And user enters beow details
      | cust_name | dob        | address    | city      | state     | pincode | mobile     | email          | password  |
      | sairam    | 02-06-1995 | Viveknagar | Hyderabad | Telangana |  500072 | 9876543210 | simha@gmail.com | Kola@1234 |
    And user clicks on submit button
    Then new customer gets created
    And user captures customer id
    And user closes the browser
