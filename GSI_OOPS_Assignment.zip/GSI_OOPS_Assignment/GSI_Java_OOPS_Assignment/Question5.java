package GSI_Java_OOPS_Assignment;


abstract class Animal
{
	abstract void sound();
}

class Dog extends Animal
{
	void sound()
	{
		System.out.println("Bow Bow");
	}
}

class Cat extends Animal 
{
	void sound()
	{
		System.out.println("Meow Meow");
	}
}

public class Question5 {
	public static void main(String[] args) {
		Dog d = new Dog();
		d.sound();
		Cat c = new Cat();
		c.sound();
		
		
	}

}
