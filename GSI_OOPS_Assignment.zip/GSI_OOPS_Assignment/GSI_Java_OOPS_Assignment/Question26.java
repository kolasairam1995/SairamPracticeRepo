package GSI_Java_OOPS_Assignment;

class School26{
	String name;
	String address;
	String strength;

	School26(String name,String address)
	{
    this.name=name;
	this.address=address;

	}
	
	School26(String name,String address, String strength)
	{
    this.name=name;
	this.address=address;
	this.strength=strength;
	}

    void display()
    {
    	System.out.println("School name is:"+" "+name);
    	System.out.println("School address is:"+" "+address);
     	System.out.println("School strength is:"+" "+strength);
     	System.out.println();
     
    }
}

public class Question26 {
	public static void main(String[] args) {
	School26 s = new School26("PNM High School", "Kukatpally, Hyderabad, Telangana");
	s.display();
	School26 s1 = new School26("PNM High School", "Kukatpally, Hyderabad, Telangana", "PHD Teachers");
    s1.display();
	}
}
