@sanity
Feature: LogoutFunctionality

  Scenario: Logout
    Given user opens browser
    And user enters username as "mngr26593"
    And user enters password as "12!@"
    When user clicks Login button
    Then user navigates to homepage of the application
    And user clicks on logout button
    And user closes the browser
