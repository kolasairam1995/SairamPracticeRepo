package GSI_Loops_Assignment;

public class Question2 {

	public static void main(String[] args) {
		
    int a=47, b=48, c=46;
    
    System.out.println("The three numbers are " + a+" "+ b+" "+c );
       
    if ((a>b && a<c)  || (a<b && a>c))
    {
    	System.out.println("a is second largest");
    }
       
    else if ((b>a && b<c)  || (b<a && b>c))
    {
    	System.out.println("b is second largest");
    }
    
    else
    {
    	System.out.println("c is second largest");
    }   
}}