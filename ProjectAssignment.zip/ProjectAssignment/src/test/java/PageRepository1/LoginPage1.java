package PageRepository1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage1 {

	WebDriver driver;
	
	public LoginPage1(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);	
	}
	
	
	@FindBy (xpath="//*[@name='uid']")
	WebElement un;
	
	@FindBy (xpath="//*[@name='password']")
	WebElement pw;
	
	@FindBy (xpath="//*[@type='submit']")
	WebElement submit;
	
	
	public void enterUserName(String uname)
	{
		un.sendKeys(uname);
	}
	
	public void enterPassword(String pwd)
	{
		pw.sendKeys(pwd);
	}
	
	
	public void click()
	{
		submit.click();
	}
	
}
