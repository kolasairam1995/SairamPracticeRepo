package GSI_Java_OOPS_Assignment;

class Shape24 {
int length=5;

void square()
{
 int s=4;
 int area =s*s;
 System.out.println("Area of square is s*s:"+" "+area);
}

void Rectangle()
{
 int b=7;
 int area=2*(length+b);
 System.out.println("Area of Rectangle is 2*(l+b):"+" "+area);
}

void circle()
{
int r=3;
double area = 2*3.14*r;
System.out.println("Area of Circle is 3.14*r*r:"+" "+area);
}
}

public class Question24 {
	public static void main(String[] args) {
	Shape24 s = new Shape24();
	s.square();
	s.Rectangle();
	s.circle();
	}

}
