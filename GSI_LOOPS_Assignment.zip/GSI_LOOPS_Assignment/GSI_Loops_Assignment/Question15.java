package GSI_Loops_Assignment;

public class Question15 {

	public static void main(String[] args) {

		int n=1, i=1;
		int sequence=1;
		
		while(i>0)
		{
			System.out.print(sequence+" ");
			sequence=sequence+n; 
			n=n+1;
			i++;		
		}
	}
}
 