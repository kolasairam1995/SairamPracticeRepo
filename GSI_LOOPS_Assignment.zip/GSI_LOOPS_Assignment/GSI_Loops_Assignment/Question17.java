package GSI_Loops_Assignment;

public class Question17 {

	public static void main(String[] args) {
		int num =4823456, div=1, dig;
		System.out.println("Given number is "+num);		
       int nbr = num;
		while(nbr>10)
		{
			nbr=nbr/10;
			div=div*10;
		}	
		do
		{
			dig=num/div;
			System.out.print(dig+" ");
			num=num%div;
			div=div/10;
		}
         while(num>0);
	}
}
