package Utilities1;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import Constants_Datas.ConstantData1;



public class FetchDataFromExcel1 {

	public static String getURL(int x, int y) throws IOException
	{
	FileInputStream f = new FileInputStream(ConstantData1.EXCEL_PROP_PATH);
	XSSFWorkbook wb = new XSSFWorkbook(f);
	XSSFSheet sh= wb.getSheetAt(0);
	XSSFCell c= sh.getRow(x).getCell(y);
	String val=c.toString();
	wb.close();
	return val;
	

	}
	

	
	
}
