package GSI_Loops_Assignment;

public class Question7 {
	public static void main(String[] args) {
		
    int a=150, b=120, c=240, d=180;
    
    if(a>b)
    {
    	if(a>c)
    		if(a>d)
    		{
    			System.out.println("a is largest");
    		}
    		else {
    			System.out.println("d is largest");
    		}
    	else
    	{
    		if(c>d)
    		{
    			System.out.println("c is largest");
    		}
    		else
    		{
    			System.out.println("d is largest");
    		}
    	}
    }
		
    else
    {
    	if(b>c)
    		if(b>d)
    		{
    			System.out.println("b is largest");
    		}
    		else
    		{
    			System.out.println("d is largest");
    		}
    	else
    	{
    		if(c>d)
    		{
    			System.out.println("c is largest");
    		}
    		else
    		{
    			System.out.println("d is largest");
    		}
    	}
    		
    }
				
	}
}
