package Utilities1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Constants_Datas.ConstantData1;



public class SendDataToExcel {
	
	  public void dataExcel(String custid) throws IOException
	    {
	        FileInputStream fs = new FileInputStream(ConstantData1.EXCEL_PROP_PATH);

	        XSSFWorkbook workbook = new XSSFWorkbook(fs);
	        XSSFSheet sheet = workbook.getSheetAt(0);

	        int row = sheet.getLastRowNum();

	        XSSFRow r = sheet.createRow(row + 1);

	        XSSFCell c = r.createCell(0);

	        c.setCellValue(custid);

	        FileOutputStream fos = new FileOutputStream(ConstantData1.EXCEL_PROP_PATH);
	        workbook.write(fos);

	        fos.close();
	        workbook.close();
	    }
	
	
	
	
	

}
