package GSI_Loops_Assignment;

public class Question11 {
	public static void main(String[] args) {
    int i=1;   
   while(i<100)
   {	if(i==77)
    	{
    		break;
    	} 
    	if(i%3==0 || i%5==0)
    	{
    		i++;
           continue;
    	}    	
    	System.out.print(i+" ");
    	i++;	
    }	
    
//    for(i=1; i<100; i++)
//    {
//    	if(i==77) {
//    		break;}
//    	if (i%3==0 || i%5==0)
//    	{
//    		continue;
//    	}
//    	System.out.println(i);
//    }  
}}
