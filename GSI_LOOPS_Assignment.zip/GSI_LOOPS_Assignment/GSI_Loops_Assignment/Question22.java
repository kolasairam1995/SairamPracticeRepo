package GSI_Loops_Assignment;

public class Question22 {

	public static void main(String[] args) {
    int rem;  
  for (int num=1000; num<=1000; num--)
	{ int rev=0; 
	  int nbr=num;
	   while(nbr>0)
	   {	      
		rem = nbr%10;
		nbr = nbr/10; 
		rev = rev*10+rem;
	   }
	   if(rev==num)
	   {
		   System.out.println(rev+" "+"Largest palindrome");
		   break;
		
	   }
	}

   
   
}
}