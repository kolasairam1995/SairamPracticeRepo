package GSI_Java_OOPS_Assignment;

class Product
{
	int productId;
	String productName;
	int price; 
	
    Product()
{
	System.out.println("Product Created");
}

    Product(int productId, String productName, int price)
    {
    	this.productId=productId;
    	this.productName=productName;
    	this.price=price;
    }
    
    void displayProduct()
    {
    	System.out.println("Product id is"+":"+" "+productId);
    	System.out.println("Product Name is"+":"+" "+productName);
    	System.out.println("Product price is"+":"+" "+price);
    }
}

public class Question3 {
	public static void main(String[] args) {
		Product p = new Product();
		Product p1 = new Product(5,"MacBook",175000);
		p1.displayProduct();
		
		 

	}

}
