package GSI_Java_OOPS_Assignment;
 
interface Transport {
	void booking();
}


class Bus implements Transport{
	public void booking() {
		System.out.println("Book via www.intercitytravels.com");
	}
}


class Flight implements Transport{
	public void booking() {
		System.out.println("Book via www.airindiatravels.com");
	}
}

public class Question18 {
	public static void main(String[] args) {
	Transport t = new Bus();
	t.booking();
	Transport t1 = new Flight();
	t1.booking();
	}

}
