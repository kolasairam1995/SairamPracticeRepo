package GSI_Loops_Assignment;
import java.util.Scanner;

public class Question20 {
	public static void main(String[] args) {
	int num, rev, rem;	
    Scanner sc = new Scanner(System.in);
    do {
    System.out.println("Enter the number");
    num = sc.nextInt();
    int nbr=num;
    rev=0; 
    while(nbr>0)
    {
    rem=nbr%10;
    nbr=nbr/10;
    rev=rev*10+rem;  
    }
    if (rev==num)
    {
    	System.out.println(rev+" "+"is a palindrome");
    	System.out.println();
    }
    else
    {
    	System.out.println("Not a palindrome");
    	break;
    }
    }
    while(num>0);
    sc.close();
      
}
}