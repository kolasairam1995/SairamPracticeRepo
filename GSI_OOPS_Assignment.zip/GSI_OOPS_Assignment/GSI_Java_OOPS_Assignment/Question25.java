package GSI_Java_OOPS_Assignment;

class School{
	String schoolname="International school"; 
    School()
  {    	 
    System.out.println("Name of the school is:"+" "+schoolname);
  }

void display()
{
	System.out.println("This School is based out of Kolkata");
}
}

public class Question25 {
	public static void main(String[] args) {
	School s = new School();
	s.display();
	}

}
