package GSI_Loops_Assignment;
import java.util.Scanner;

public class Question5 {
	public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number");
    int num= sc.nextInt();
    
    if(num%2==0)
    {
    	if(num%3==0)
    	{
    		System.out.println("\"A\"");
    	}
    	else
    	{
    		System.out.println("\"C\"");
    	}
    }
    	
    else
    {
    	if(num%3==0)
    	{
    		System.out.println("\"B\"");
    	}
    	else
    	{
    		System.out.println("\"D\"");
    	}
    }
    	
    	sc.close();
    
	}
}
