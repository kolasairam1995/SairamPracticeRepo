package GSI_Loops_Assignment;

public class Question21 {

	public static void main(String[] args) {
    for (int i=1; i<500; i++)
    {
    	if(i%3==0)
    	{
    		System.out.print(i+" ");
    	}
    }
	}

}
 