package GSI_Java_OOPS_Assignment;

class GovernmentRules {
	final int MAX_WORKING_HOURS = 8;
}

public class Question22 {
	public static void main(String[] args) {
	GovernmentRules g = new GovernmentRules();
	g.MAX_WORKING_HOURS=10; //  Compile time error
	}

}
