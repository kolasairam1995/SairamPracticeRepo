package GSI_Java_OOPS_Assignment;

class Camera{
	void capture()
	{
		System.out.println("Take photos");
	}
}

class DSLCamera extends Camera{
	void capture()
	{
		System.out.println("DSL Camera gives: 4K HD clarity photos");
	}
	
}


public class Question19 {
	public static void main(String[] args) {
    Camera c = new DSLCamera();
    c.capture();
	}

}
