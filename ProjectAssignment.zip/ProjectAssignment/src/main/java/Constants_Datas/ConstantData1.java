package Constants_Datas;

public class ConstantData1 {
public static final String PROP_FILE_PATH="src/main/java/Global.properties";
	
	public static final String EXCEL_PROP_PATH="D:/Book1.xlsx";
}
