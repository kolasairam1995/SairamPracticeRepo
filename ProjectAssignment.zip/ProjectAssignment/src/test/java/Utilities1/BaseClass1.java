package Utilities1;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class BaseClass1 {
	static String browsername;	
	public static WebDriver driver;
		
	public static WebDriver initiaizeDriver() 
	{	
		try {
			browsername=FetchDataFromProperty1.getDataFromProperty().getProperty("browser");
		} catch (IOException e) {
			e.printStackTrace();
		}		
		if(browsername.equalsIgnoreCase("chrome"))
		{
			driver = new ChromeDriver();
			try {
				driver.get(FetchDataFromExcel1.getURL(1, 0));
			} catch (IOException e) {
				e.printStackTrace();
			}
			driver.manage().window().maximize();
		}
	
		if(browsername.equalsIgnoreCase("edge"))
		{
			driver = new EdgeDriver();
			try {
				driver.get(FetchDataFromExcel1.getURL(1, 0));
			} catch (IOException e) {
				e.printStackTrace();
			}
			driver.manage().window().maximize();
		}		
		return driver;		
	}
	
	
	
	public static String getTitle()
	{
		String title= driver.getTitle();
		return title;
	} 
	
	
	public static void scrollpae()
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("windows.scrollBy(0,500)", "");	
	}
	
	
	public static String getCurrentURL()
	{
		String CURL = driver.getCurrentUrl();
		return CURL;
	}
	
	
	public static void closeBrowser() throws InterruptedException
	{
		Thread.sleep(5000);
		driver.quit();
	}
	
	
	public static void addExplicitWait()
	{
		
		WebDriverWait x=new WebDriverWait(driver,Duration.ofSeconds(10));
		
		WebElement ele=	x.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#Skills")));
	}
	
	

}
