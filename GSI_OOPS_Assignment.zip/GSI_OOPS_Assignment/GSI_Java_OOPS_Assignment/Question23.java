package GSI_Java_OOPS_Assignment;

class Mall {
	Mall()
	{
		System.out.println("Welcome to the Mall");
	}
	Mall(int x)
	{
		this();
		System.out.println("Parameterized constructor:"+" "+x);
	}
}

public class Question23 {
	public static void main(String[] args) {
	Mall m = new Mall(10);
	}

}
