package GSI_Java_OOPS_Assignment;

class University {
	static String country="India";
	String universityName;
	
	University(String universityName)
	{
		this.universityName=universityName;
	}
	
	void display()
	{
		System.out.println("Country:"+" "+country+" "+"University:"+" "+universityName);
	}
}


public class Question21 {
	public static void main(String[] args) {
	University u = new University("GITAM");
	u.display();	
	University u1 = new University("SRM");
	u1.display();
	
	}

}
