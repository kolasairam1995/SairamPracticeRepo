package GSI_Java_OOPS_Assignment;

class Shape{
	void area() {
		System.out.println("area");
	}
}

class Rectangle extends Shape{
	void area()
	{
		System.out.println("Area of rectangle is 2(l+b)");
	}
}

class Circle extends Shape{
	void area()
	{
		System.out.println("Area of circle is 3.14*r*r");
	}
}

public class Question8 {
	public static void main(String[] args) {
		Shape s = new Rectangle();
		s.area();		
		Shape s1 = new Circle();
		s1.area();
	}
}





















