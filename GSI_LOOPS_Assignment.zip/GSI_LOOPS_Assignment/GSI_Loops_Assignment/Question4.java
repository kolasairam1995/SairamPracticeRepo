package GSI_Loops_Assignment;

import java.util.Scanner;

public class Question4 {
	public static void main(String[] args) {
   Scanner sc = new Scanner(System.in);
   System.out.println("Enter the number");
   int num = sc.nextInt();
   
   if(num>0)
   {
	   if(num%4==0)
	   {   System.out.println("Given number is positive");
		   System.out.println("Number divisible by 4");
	   }
	   else
	   {   System.out.println("Given number is positive");
		   System.out.println("Number not divisible by 4");  
	   }
   }
   else
   {
	   if(num%6==0)
	   {   System.out.println("Given number is Negative");
		   System.out.println("Number divisible by 6");
	   }
	   else
	   {   System.out.println("Given number is Negative");
		   System.out.println("Number not divisible by 6");
	   }
   }
   sc.close();
		
	}

}
