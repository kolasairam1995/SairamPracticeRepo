package GSI_Java_OOPS_Assignment;

class Hospital{
	void emergencyService()
	{
		System.out.println("EmergencyService from Hospital class");
	}
}

class CityHospital extends Hospital{
	void emergencyService()
	{
		System.out.println("EmergencyService from CityHospital class");
		super.emergencyService();
	}
}

public class Question16 {
	public static void main(String[] args) {
	CityHospital c = new CityHospital();
	c.emergencyService();
	}

}
