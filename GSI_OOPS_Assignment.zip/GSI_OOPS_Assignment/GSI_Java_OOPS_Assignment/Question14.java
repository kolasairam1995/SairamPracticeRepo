package GSI_Java_OOPS_Assignment;

class Course{
	void courseInfo()
	{
		System.out.println("Details of course info");
	}
}

class Science extends Course{
	void courseInfo()
	{
		System.out.println("Course name: MPC");
	}
}

class Commerce extends Course
{ 
	void courseInfo()
	{
		System.out.println("Course name: CEC");
	}
}

class Arts extends Course{
	void courseInfo()
	{
		System.out.println("Course name: AEC");
	}
}

public class Question14 {
	public static void main(String[] args) {
		Science s = new Science();
		s.courseInfo();
		Commerce c = new Commerce();
		c.courseInfo();
		Arts a = new Arts();
		a.courseInfo();
		

	}

}
