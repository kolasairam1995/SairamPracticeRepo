package GSI_Java_OOPS_Assignment;

class Employee
{   	private int empId;
        private String empName;
        private int salary;
        
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getSalary() {
		return salary; 
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	void displayDetails()
	{
		System.out.println("Employee_id is"+":"+" "+empId);
		System.out.println("Employee name is"+":"+" "+empName);
		System.out.println("Employee salary is"+":"+" "+salary);
	}
}

public class Question1 {
	public static void main(String[] args) {
		Employee e = new Employee();
		e.setEmpId(1);
		e.setEmpName("SAIRAM");
		e.setSalary(135000);
		e.displayDetails();
		
	}

}
