package GSI_Loops_Assignment;

public class Question8 {
	public static void main(String[] args) {
		
		int age =30, salary=95000;
		
		if(age>=25) 
		{
			if(age>=30)
			{
				if (salary>=50000)
				{
					System.out.println("Eligible for loan B");
				}
				else
				{
					System.out.println("Not Eligible for loan B");
				}
			}
			else
			{
				if(salary<30000)
				{
					System.out.println("Eligible for loan A");
				}
				else
				{
					System.out.println("Not Eligible for loan A");
				}
			}				
			}	
		else
		{
			System.out.println("Not eligible");
		}
	}
}
