package GSI_Loops_Assignment;

public class Question14 {
	
	public static void main(String[] args) {
		
    int n1=0, n2=1, n3;
    
    for(int i=1; i>0; i++)
    {
    	if(n1>500)
    	{
    		break;
    	}
    	System.out.print(n1+" ");	
    	n3=n1+n2;
    	n1=n2; 
    	n2=n3;
    	
    }
		
		
		
		
	}

}
