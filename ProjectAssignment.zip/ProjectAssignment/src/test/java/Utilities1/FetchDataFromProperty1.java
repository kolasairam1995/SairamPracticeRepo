package Utilities1;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import Constants_Datas.ConstantData1;

public class FetchDataFromProperty1 {
	public static Properties getDataFromProperty() throws IOException
	{
		FileReader f = new FileReader(ConstantData1.PROP_FILE_PATH);
		Properties p = new Properties();
		p.load(f);
		return p;
		
	}
}
