package StepDefinations;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;

import PageRepository1.LoginPage1;
import PageRepository1.NewCustomerPage1;
import Utilities1.BaseClass1;
import Utilities1.FetchCustidFromExcel;
import Utilities1.FetchDataFromExcel1;
import Utilities1.SendDataToExcel;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefination extends BaseClass1 {
	
	WebDriver driver = BaseClass1.initiaizeDriver();
	LoginPage1 lp = new LoginPage1(driver);
	NewCustomerPage1 n = new NewCustomerPage1(driver);
		
		
	@Given("user opens browser")
	public void user_opens_browser() {
	    getTitle();
	}

		@Given("user enters username as {string}")
		public void user_enters_username_as(String username) {
		   lp.enterUserName(username);
		}

		@Given("user enters password as {string}")
		public void user_enters_password_as(String password) {
		    lp.enterPassword(password);
		}

		@When("user clicks Login button")
		public void user_clicks_login_button() {
		    lp.click();
		}

		@Then("user navigates to homepage of the application")
		public void user_navigates_to_homepage_of_the_application() {
			
			String CURL1=getCurrentURL();
			
			if(CURL1.contains("homepage"))
			{
				System.out.println("user navigated correct page");
			}
			else
			{
				throw new NullPointerException("Page navigation not successful");
			}
		}
	
	
		@Given("user clicks on new customer link")
		public void user_clicks_on_new_customer_link() {
		   n.clickNewCustomerLink();
		}
	
	
		 
		@Then("user enters beow details")
		public void user_enters_beow_details(io.cucumber.datatable.DataTable dataTable) {

		    List<List<String>> data = dataTable.asLists(String.class);

		    String custname = data.get(1).get(0);
		    n.enterUsername(custname);

		    String dob = data.get(1).get(1);
		    n.enterDob(dob);

		    String add = data.get(1).get(2);
		    n.enterAddr(add);

		    String city = data.get(1).get(3);
		    n.enterCity(city);

		    String state = data.get(1).get(4);
		    n.enterState(state);

		    String pin = data.get(1).get(5);
		    n.enterPincode(pin);

		    String mob = data.get(1).get(6);
		    n.enterMobile(mob);

		    String cust_email = data.get(1).get(7);
		    n.enterEmail(cust_email);

		    String pwd = data.get(1).get(8);
		    n.enterPassword(pwd);
		}
		
		@Given("user clicks on submit button")
		public void user_clicks_on_submit_button() {
	    n.clickSubmit();	    
		}

		
		
		@Then("new customer gets created")
		public void new_customer_gets_created() {
		    
			System.out.println(n.captureCustID());
			
			
		}

		
		
		@Then("user captures customer id")
		public void user_captures_customer_id() throws IOException {		
		String d=n.captureCustID();
		SendDataToExcel s= new SendDataToExcel();
		s.dataExcel(d);   
		}


		@Then("customer clicks on New account link")
		public void customer_clicks_on_new_account_link() {		
			n.clickNewAccount();		   
		}

		@Then("customer enters customerid")
		public void customer_enters_customerid() throws IOException {
			
			String d=FetchCustidFromExcel.getCustomerID(0, 17);
			n.enterCustid(d);
		    
		}

		@Then("customer enters deposit as {string}")
		public void customer_enters_deposit_as(String deposit) {
		    
			n.enterDeposit(deposit);
			
		}

		@Then("user clicks on account submit button")
		public void user_clicks_on_account_submit_button() {
		    n.clickSubmit1();
		}

		@Then("new account gets created")
		public void new_account_gets_created() {
		    System.out.println("account created");
		}

		@Then("user captures account id")
		public void user_captures_accont_id() throws IOException {
			String a=n.captureAcctID();
			SendDataToExcel k= new SendDataToExcel();
			k.dataExcel(a); 
		    
		}
	
	
		@Then("user clicks on logout button")
		public void user_clicks_on_logout_button() throws InterruptedException {
		    n.clicklogout();
		}
		
		@Then("user closes the browser")
		public void user_closes_the_browser() throws InterruptedException {
			closeBrowser();
		}	
}
