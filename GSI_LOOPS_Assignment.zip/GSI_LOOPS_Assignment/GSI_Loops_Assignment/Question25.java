package GSI_Loops_Assignment;

public class Question25 {

	public static void main(String[] args) {
    System.out.println("Perfect numbers between 1 & 10000 are:");
    System.out.println();
    
   for(int i=1; i<10000; i++)
   {
    int count=0;
    for(int j=1; j<=i/2; j++)
    {
    	if (i%j==0)
    	{
    		count=count+j;
    	}
    }
    if(count==i)
    {
    	System.out.print(i+" ");  
    }
    }

}
}  